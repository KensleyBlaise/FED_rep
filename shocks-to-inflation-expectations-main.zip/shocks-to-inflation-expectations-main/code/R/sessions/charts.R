################################################################################
# Minimal charts.R
# Only: Structural IRFs for the sentiment shock (baseline cases 1 & 2, monthly)
################################################################################

library(tidyverse)

#### 1. Labels for the variables you actually have ####
var.labs <- c(
  michigan.fcast   = "Inflation, one year ahead\ncumulative, forecast",
  inf.cpi          = "Inflation, annual rate",
  inf.cpi.first    = "Inflation, annual rate,\ninitial release",
  inf.commod       = "Commodity price inflation",
  fed.funds.rate   = "Federal Funds Rate",
  unemp            = "Unemployment",
  log.ip           = "Log Industrial Production * 100"
)

# Variables that should be annualized in the IRFs (monthly → *12)
annualize.vars <- c("inf.cpi", "inf.cpi.first")

#### 2. Structural IRFs (sentiment shock) ####

# Compute structural IRFs from the VAR solution
df.irf.struct <- make.irf.struct(
  l.var.coefs,
  est.A$A,
  fcast.horiz = fcast.horiz,
  inf.name    = x,
  n.pds       = irf.pds,
  fcast       = fcast,
  fcast.cumul = fcast.cumul
)

# Keep only the sentiment shock(s)
df.irf.sent <- df.irf.struct %>%
  filter(grepl("Sentiment", shock)) %>%        # e.g. "Sentiment #1"
  mutate(
    outcome.lab = var.labs[outcome],
    value       = ifelse(outcome %in% annualize.vars, value * 12, value)
  ) %>%
  filter(!is.na(outcome.lab))                  # drop anything without a label

# Build confidence bands from the bootstrap output
bands.sent <- est.bootstrap$structural %>%
  filter(grepl("Sentiment", shock)) %>%
  mutate(
    outcome.lab = var.labs[outcome],
    q.05        = ifelse(outcome %in% annualize.vars, q.05 * 12, q.05),
    q.95        = ifelse(outcome %in% annualize.vars, q.95 * 12, q.95)
  ) %>%
  filter(!is.na(outcome.lab))

# Safety: if for some reason there is no sentiment shock, skip instead of error
if (nrow(df.irf.sent) == 0 || nrow(bands.sent) == 0) {
  message("No sentiment IRFs found – skipping structural IRF plot.")
} else {
  
  gg.irfs.struct.sent <- ggplot() +
    geom_hline(yintercept = 0, linewidth = 0.4) +
    geom_ribbon(
      data = bands.sent,
      aes(x = period, ymin = q.05, ymax = q.95),
      alpha = 0.25
    ) +
    geom_path(
      data = df.irf.sent,
      aes(x = period, y = value),
      linewidth = 0.9
    ) +
    facet_wrap(~ outcome.lab, scales = "free_y") +
    theme_minimal() +
    labs(
      x = "Horizon",
      y = "Percentage points"
    ) +
    scale_x_continuous(
      breaks = seq(0, irf.plot.pds, 6),
      limits = c(0, irf.plot.pds)
    )
  
  print(gg.irfs.struct.sent)
  
  ggsave(
    paste0(
      "graphs/", figure.location,
      "/irf_struct_sentiment_", init.yr, "_", freq, "_",
      l.var.coefs$lags, "_lags.pdf"
    ),
    gg.irfs.struct.sent,
    height = 8, width = 10
  )
}
