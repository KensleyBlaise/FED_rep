##########################################################################################
# make_big_var_fns.R (robust)
##########################################################################################

library(tidyverse)
library(BigVAR)
library(expm)
library(magrittr)
select <- dplyr::select  # avoid MASS::select

make.big.var <- function(df, value.name, var.name, fcast, inf, y,
                         lag.max = 24, m.Y = NA, ...) {
  # --- Build data matrix if not supplied ---
  if (length(m.Y) == 1L && is.na(m.Y)) {
    m.Y <- df %>%
      dplyr::filter( !!as.symbol(var.name) %in% c(fcast, inf, y) ) %>%
      dplyr::select(date, !!as.symbol(var.name), !!as.symbol(value.name)) %>%
      tidyr::pivot_wider(names_from = !!as.symbol(var.name),
                         values_from = !!as.symbol(value.name)) %>%
      dplyr::arrange(date) %>%
      dplyr::select(all_of(c(fcast, inf, y))) %>%
      as.matrix()
  }
  
  stopifnot(is.matrix(m.Y), is.numeric(m.Y))
  n.vars    <- ncol(m.Y)
  var.names <- colnames(m.Y)
  y.means   <- colMeans(m.Y)
  
  # --- Allowed structs per BigVAR ---
  allowed_struct <- c("Basic","Lag","SparseLag","OwnOther","SparseOO",
                      "HLAGC","HLAGOO","HLAGELEM","Tapered","EFX","BGR",
                      "BasicEN","MCP","SCAD")
  
  # --- Merge user dots; validate/sanitize struct/gran etc. ---
  dots <- list(...)
  # coerce struct to a clean scalar character
  user_struct <- dots$struct
  user_struct <- if (is.null(user_struct)) NA_character_ else as.character(user_struct)[1]
  if (is.na(user_struct) || !(user_struct %in% allowed_struct)) {
    struct <- "Basic"
  } else {
    struct <- user_struct
  }
  
  # gran must be length-2 numeric
  gran <- dots$gran
  if (is.null(gran)) gran <- c(50,10)
  gran <- as.numeric(gran)
  if (length(gran) != 2 || any(!is.finite(gran))) gran <- c(50,10)
  
  # optional flags (don’t force if user provided)
  RVAR    <- if (is.null(dots$RVAR)) FALSE else isTRUE(dots$RVAR)
  MN      <- if (is.null(dots$MN))   FALSE else isTRUE(dots$MN)
  verbose <- if (is.null(dots$verbose)) FALSE else isTRUE(dots$verbose)
  IC      <- if (is.null(dots$IC)) TRUE else isTRUE(dots$IC)
  
  # model.controls: set intercept = FALSE if none supplied
  model.controls <- dots$model.controls
  if (is.null(model.controls)) model.controls <- list(intercept = FALSE)
  
  # Build argument list, deduping anything in dots
  base_args <- list(
    Y = m.Y,
    p = lag.max,
    struct = struct,
    gran = gran
  )
  # Keep extra user args except those we set explicitly
  drop_keys <- c("Y","p","struct","gran","RVAR","MN","verbose","IC","model.controls")
  extra_args <- dots[setdiff(names(dots), drop_keys)]
  
  # --- Try modern signature; fallback to minimal if needed ---
  mod <- tryCatch(
    do.call(BigVAR::constructModel, c(base_args,
                                      list(RVAR = RVAR, MN = MN, verbose = verbose, IC = IC,
                                           model.controls = model.controls),
                                      extra_args)),
    error = function(e) {
      # Older BigVAR versions may not accept some args; drop them.
      do.call(BigVAR::constructModel, c(base_args, extra_args))
    }
  )
  
  res <- BigVAR::cv.BigVAR(mod)
  
  # Companion top block coefficients (like your original)
  m.B.1 <- res@betaPred[, -1, drop = FALSE] %>%
    set_rownames(var.names) %>%
    set_colnames(paste0(rep(var.names, lag.max), ".l", rep(1:lag.max, each = n.vars)))
  
  if (lag.max == 1) {
    m.B <- m.B.1
  } else {
    lagmat <- cbind(diag(n.vars * (lag.max - 1)),
                    matrix(0, n.vars * (lag.max - 1), n.vars))
    rownames(lagmat) <- colnames(m.B.1)[1:(n.vars * (lag.max - 1))]
    m.B <- rbind(m.B.1, lagmat)
  }
  
  m.Sigma <- res@resids %>% set_colnames(var.names) %>% var()
  
  list(B = m.B, Sigma = m.Sigma, n.vars = n.vars, lags = lag.max,
       mu = y.means, data = m.Y, bigvar = res)
}
